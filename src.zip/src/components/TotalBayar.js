import React, { Component } from 'react'

export default class TotalBayar extends Component {
  render() {
    return (
      <div>
        <h4>Total Harga : Rp. </h4>
      </div>
    )
  }
}
